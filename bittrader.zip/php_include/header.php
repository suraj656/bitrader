<header class="header-section header-section--style2">
    <div class="header-bottom">
      <div class="container">
        <div class="header-wrapper">
          <div class="logo">
            <a href="index.php">
              <img class="dark" src="assets/images/logo/logo.png" alt="logo">
            </a>
          </div>
          <div class="menu-area">
            <ul class="menu menu--style1">
              <li class="megamenu">
                <a href="index.php">Home</a>
              </li>
              <li>
                <a href="about.php">About Us</a>
                
              </li>
              <li>
                <a href="whatwedo.php">What We Do</a>
                
              </li>
              <li>
                <a href="login.php">Login </a>
               
              </li>
              <li>
                <a href="register.php">Register </a>
              </li>

              <li>
                <a href="contactus.php">Contact Us</a>
              </li>
            </ul>

          </div>
          <div class="header-action">
            <div class="menu-area">
              <div class="header-btn">
                <a href="register.php" class="trk-btn trk-btn--border trk-btn--primary">
                  <span>Register</span>
                </a>
              </div>

              <!-- toggle icons -->
              <div class="header-bar d-lg-none header-bar--style1">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>