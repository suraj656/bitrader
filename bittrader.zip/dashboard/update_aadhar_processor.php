<?php
        session_start();
        include('php_include/check_login.php');
        include("php_include/connect.php");
        $userid = $_SESSION['userid'];
                  if(isset($_POST['submit1'])){
                      $aadhaar_no  =  mysqli_real_escape_string($con,$_POST['adhar_num']);
                      $adhar_frn_pic=$_FILES["adhar_fro_pic"]["name"];
                      $trn_password  =  mysqli_real_escape_string($con,$_POST['trn_pass']);
       
                      $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid' AND `trn_password` = '$trn_password'");
                            if(mysqli_num_rows($query_password_check)==1){
                                $query=mysqli_query($con,"UPDATE `kyc` SET `adhar_num`='$aadhaar_no ',`adhar_front_pic`='$adhar_frn_pic' WHERE `userid`='$userid' AND `trn_password`='$trn_password'");
                                $newname = $adhar_frn_pic;  
                                $target = 'kyc/'.$newname;
                                move_uploaded_file( $_FILES['adhar_fro_pic']['tmp_name'], $target);    
                                    
                                    if($query){
                                                echo "<script>alert('Aadhar front image updated');window.location.assign('update_aadhar.php');</script>";
                                              }else{
                                                      echo "<script>alert('Aadhar front image failed');window.location.assign('update_aadhar.php');</script>";
                                             }
                            }else{
                                echo "<script>alert('TRN Password Entered is wrong!');window.location.assign('update_aadhar.php');</script>";
                            }
                  }else{
                      
                  } 
                  
                  if(isset($_POST['submit2'])){
                      $adhar_back_pic=$_FILES["adhar_back_pic"]["name"];
                      $trn_password  =  mysqli_real_escape_string($con,$_POST['trn_pass']);
       
                      $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid' AND `trn_password` = '$trn_password'");
                            if(mysqli_num_rows($query_password_check)==1){
                                $query=mysqli_query($con,"UPDATE `kyc` SET `adhar_back_pic`='$adhar_back_pic' WHERE `userid`='$userid' AND `trn_password`='$trn_password'");
                                $newname = $adhar_back_pic;  
                                $target = 'kyc/'.$newname;
                                move_uploaded_file( $_FILES['adhar_back_pic']['tmp_name'], $target);    
                                    
                                    if($query){
                                                echo "<script>alert('Aadhar Back image updated');window.location.assign('index.php');</script>";
                                              }else{
                                                      echo "<script>alert('Aadhar Back image failed');window.location.assign('update_aadhar.php');</script>";
                                             }
                            }else{
                                echo "<script>alert('TRN Password Entered is wrong!');window.location.assign('update_aadhar.php');</script>";
                            }
                  }else{
                      
                  } 
                  
                  
                 ?>