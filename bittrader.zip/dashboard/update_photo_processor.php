<?php
        session_start();
        include('php_include/check_login.php');
        include("php_include/connect.php");
        $userid = $_SESSION['userid'];
                  if(isset($_POST['submit'])){
                      
                      $profile_pic=$_FILES["profile_pic"]["name"];
                      $trn_password  =  mysqli_real_escape_string($con,$_POST['trn_pass']);
       
                      $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid' AND `trn_password` = '$trn_password'");
                            if(mysqli_num_rows($query_password_check)==1){
                                $query=mysqli_query($con,"UPDATE `user` SET `profile_pic`='$profile_pic' WHERE `userid`='$userid' AND `trn_password`='$trn_password'");
                                $newname = $profile_pic;  
                                $target = 'kyc/'.$newname;
                                move_uploaded_file( $_FILES['profile_pic']['tmp_name'], $target);    
                                    
                                    if($query){
                                                echo "<script>alert('Profile pic updated');window.location.assign('index.php');</script>";
                                              }else{
                                                      echo "<script>alert('Profile pic update failed');window.location.assign('update_photo.php');</script>";
                                             }
                            }else{
                                echo "<script>alert('TRN Password Entered is wrong!');window.location.assign('update_photo.php');</script>";
                            }
                  }else{
                      
                  } 

                 ?>