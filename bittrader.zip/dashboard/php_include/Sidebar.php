<div class="container-fluid">

                    <div id="two-column-menu">
                    </div>
                    <ul class="navbar-nav" id="navbar-nav">
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="index.php">
                                <i class="las la-house-damage"></i> <span data-key="t-dashboard">Dashboard</span>
                            </a>
                        </li>

                        

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarInvoiceManagement" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarInvoiceManagement">
                                <i class="las la-file-invoice"></i> <span data-key="t-invoices">Profile Menu</span>
                            </a>
                            
                            <div class="collapse menu-dropdown" id="sidebarInvoiceManagement">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="edit_personal.php" class="nav-link" data-key="t-invoice"> Personal Details </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="edit_nominal.php" class="nav-link" data-key="t-invoice"> Nominal Details </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a href="edit_trnpass.php" class="nav-link" data-key="t-add-invoice"> Transaction Password </a>
                                    </li>


                                    <li class="nav-item">
                                        <a href="edit_password.php" class="nav-link" data-key="t-invoice-details"> Login password </a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="update_aadhar.php" class="nav-link" data-key="t-payments">Update Aadhar</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="update_it.php" class="nav-link" data-key="t-taxes">Update IT(Pan Card)</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="update_bank.php" class="nav-link" data-key="t-taxes">Update Bank Details</a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a href="update_photo.php" class="nav-link" data-key="t-taxes">Update Photo</a>
                                    </li>
                                    

                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarAdvanceUI12" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAdvanceUI">
                                <i class="las la-share-alt"></i> <span data-key="t-advance-ui">Accounts Menu</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarAdvanceUI12">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-signin">Income Report</a>
                                    </li>
                                    
                                </ul>
                            </div>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarAuthentication" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAuthentication">
                                <i class="las la-cog"></i> <span data-key="t-authentication">Associate Menu</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarAuthentication">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="direct_sponesor.php" class="nav-link" data-key="t-signin">Direct Sponesor</a>
                                    </li>
                                    
                                </ul>
                            </div>
                        </li>

                        

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarUI" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarUI">
                                <i class="las la-pen-nib"></i> <span data-key="t-bootstrap-ui">Wallet Menu</span>
                            </a>
                            <div class="collapse menu-dropdown mega-dropdown-menu" id="sidebarUI">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <ul class="nav nav-sm flex-column">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link" data-key="t-alerts">Wallet Request</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link" data-key="t-badges">Transfer to others</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link" data-key="t-buttons">Earning to Main Wallet</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link" data-key="t-colors">Transfer History</a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link" data-key="t-cards">Account Activation</a>
                                            </li>
                                            
                                        </ul>
                                    </div>
                    
                                </div>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarAdvanceUI" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarAdvanceUI">
                                <i class="las la-share-alt"></i> <span data-key="t-advance-ui">Promotional Tools</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarAdvanceUI">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-sweet-alerts">PPT/PDF</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-nestable-list">Banner Vedio</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-scrollbar">Banner Images</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-swiper-slider">Animation Vedio</a>
                                    </li>
                                  
                                </ul>
                            </div>
                        </li>

                        

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarTables" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarTables">
                                <i class="las la-table"></i> <span data-key="t-tables">Chating Box</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarTables">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-basic-tables">Chat to Admin</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-grid-js">Chat to others</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link" data-key="t-list-js">Chating History</a>
                                    </li>
                                    
                                </ul>
                            </div>
                        </li>

                       
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="logout.php">
                                <i class="las la-house-damage"></i> <span data-key="t-dashboard">Logout</span>
                            </a>
                        </li>

                        

                    </ul>
                </div>