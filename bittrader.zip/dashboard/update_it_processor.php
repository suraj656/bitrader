<?php
        session_start();
        include('php_include/check_login.php');
        include("php_include/connect.php");
        $userid = $_SESSION['userid'];
                  if(isset($_POST['submit'])){
                      $pan_num =  mysqli_real_escape_string($con,$_POST['pan_num']);
                      $pan_pic=$_FILES["pan_pic"]["name"];
                      $trn_password  =  mysqli_real_escape_string($con,$_POST['trn_pass']);
       
                      $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid' AND `trn_password` = '$trn_password'");
                            if(mysqli_num_rows($query_password_check)==1){
                                $query=mysqli_query($con,"UPDATE `kyc` SET `pan_num`='$pan_num', `pan_pic`='$pan_pic' WHERE `userid`='$userid' AND `trn_password`='$trn_password'");
                                $newname = $pan_pic;  
                                $target = 'kyc/'.$newname;
                                move_uploaded_file( $_FILES['pan_pic']['tmp_name'], $target);    
                                    
                                    if($query){
                                                echo "<script>alert('Pan card image updated');window.location.assign('index.php');</script>";
                                              }else{
                                                      echo "<script>alert('Pan card image failed');window.location.assign('update_it.php');</script>";
                                             }
                            }else{
                                echo "<script>alert('TRN Password Entered is wrong!');window.location.assign('update_it.php');</script>";
                            }
                  }else{
                      
                  } 

                 ?>