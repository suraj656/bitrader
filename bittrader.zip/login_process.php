
<?php
    session_start();
   include("php_include/connect.php");
   if(isset($_POST['submit'])){
       
       $mob_num = mysqli_real_escape_string($con, $_POST["mob_number"]);
       $password = mysqli_real_escape_string($con, $_POST["password"]);
       
      $query= mysqli_query($con,"SELECT * FROM `user` WHERE `mob_num`='$mob_num' AND `password`='$password'");
      $row=mysqli_fetch_array($query);
      $userid =$row['userid'];
      if(mysqli_num_rows($query)>0){
        
        $_SESSION['userid'] = $userid;
	    $_SESSION['id'] = session_id();
	    $_SESSION['login_type'] = "user"; 
	    
           echo "<script>alert('Login succesful');window.location.assign('dashboard/index.php');</script>";
        } else {
                  echo "<script>alert('Login Unsuccesful');window.location.assign('login.php');</script>";
                }
    }else{
        
    }
?>