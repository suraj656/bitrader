<?php
    session_start();
    include('php_include/check_login.php');
    include("php_include/connect.php");
    $userid = $_SESSION['userid'];
    if(isset($_POST['submit'])){
        
        $old_pass=mysqli_real_escape_string($con,$_POST['old_pass']);
        $new_pass=mysqli_real_escape_string($con,$_POST['new_pass']);
        $conf_pass=mysqli_real_escape_string($con,$_POST['conf_pass']);

            $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid` = '$userid' AND `password` = '$old_pass'");
            if(mysqli_num_rows($query_password_check)==1){
                if($new_pass===$conf_pass){
                    
               $query=mysqli_query($con,"UPDATE `user` SET `password`='$new_pass' WHERE `userid` = '$userid'");
                                            
               if($query){
                         echo "<script>alert('Password updated');window.location.assign('index.php');</script>";
                    }else{
                         echo "<script>alert('Password update failed');window.location.assign('edit_password.php');</script>";
                    }
            }else{
                    echo "<script>alert('New Password and confirm Password Dont Match');window.location.assign('edit_password.php');</script>";
                }        
                    
            }else{
                    echo "<script>alert('Password Entered is wrong!');window.location.assign('edit_password.php');</script>";
            }
    }else{
        
    }
    
?>