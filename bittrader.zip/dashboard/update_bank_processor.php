<?php
        session_start();
        include('php_include/check_login.php');
        include("php_include/connect.php");
        $userid = $_SESSION['userid'];
                  if(isset($_POST['submit'])){
                      $acc_num=  mysqli_real_escape_string($con,$_POST['acc_num']);
                      $ifsc_code=  mysqli_real_escape_string($con,$_POST['ifsc_code']);
                      $bank_name=  mysqli_real_escape_string($con,$_POST['bank_name']);
                      $branch=  mysqli_real_escape_string($con,$_POST['branch']);
                      $acc_name=  mysqli_real_escape_string($con,$_POST['acc_name']);
                      $bank_pic=$_FILES["bank_pic"]["name"];
                      $trn_password  =  mysqli_real_escape_string($con,$_POST['trn_pass']);
       
                      $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid' AND `trn_password` = '$trn_password'");
                            if(mysqli_num_rows($query_password_check)==1){
                                $query=mysqli_query($con,"UPDATE `bank_details` SET `account_num`='$acc_num',`ifsc_code`='$ifsc_code',`bank_name`='$bank_name',`branch`='$branch',`account_name`='$acc_name',`bank_pic`='$bank_pic' WHERE `userid`='$userid' AND `trn_password`='$trn_password'");
                                $newname = $bank_pic;  
                                $target = 'kyc/'.$newname;
                                move_uploaded_file( $_FILES['bank_pic']['tmp_name'], $target);    
                                    
                                    if($query){
                                                echo "<script>alert('Bank Details updated');window.location.assign('index.php');</script>";
                                              }else{
                                                      echo "<script>alert('Bank Details update failed');window.location.assign('update_bank.php');</script>";
                                             }
                            }else{
                                echo "<script>alert('TRN Password Entered is wrong!');window.location.assign('update_bank.php');</script>";
                            }
                  }else{
                      
                  } 

                 ?>