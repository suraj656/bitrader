<!DOCTYPE html>
<html lang="en" data-bs-theme="light">

<head>
    <?php 
           include("php_include/head.php");
    ?>
</head>

<body>

  <!-- ===============>> Preloader start here <<================= -->
  <div class="preloader">
    <img src="assets/images/logo/preloader.png" alt="preloader icon">
  </div>
  <!-- ===============>> Preloader end here <<================= -->



  <!-- ===============>> light&dark switch start here <<================= -->
  <div class="lightdark-switch">
    <span class="switch-btn" id="btnSwitch"><img src="assets/images/icon/moon.svg" alt="light-dark-switchbtn"
        class="swtich-icon"></span>
  </div>
  <!-- ===============>> light&dark switch start here <<================= -->





  <!-- ===============>> Header section start here <<================= -->
        <?php 
           include("php_include/header.php");
        ?>
  <!-- ===============>> Header section end here <<================= -->



  <!-- ================> Page header start here <================== -->
  <section class="page-header bg--cover" style="background-image:url(assets/images/header/1.png)">
    <div class="container">
      <div class="page-header__content" data-aos="fade-right" data-aos-duration="1000">
        <h2>Login</h2>
        <nav style="--bs-breadcrumb-divider: '/';" aria-label="breadcrumb">
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item "><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Login</li>
          </ol>
        </nav>
      </div>
      <div class="page-header__shape">
        <span class="page-header__shape-item page-header__shape-item--1"><img src="assets/images/header/2.png"
            alt="shape-icon"></span>
      </div>
    </div>
  </section>
  <!-- ================> Page header end here <================== -->





  <!-- ===============>> account start here <<================= -->
  <section class="account padding-top padding-bottom sec-bg-color2">
    <div class="container">
      <div class="account__wrapper" data-aos="fade-up" data-aos-duration="800">
        <div class="row g-4">
          <div class="col-lg-12">
            <div class="account__content account__content--style1">

              <!-- account tittle -->
              <div class="account__header">
                <h2>Welcome back!</h2>
                <p>Hey there! Ready to log in? Just enter your username and password below and you'll be back in action
                  in no time. Let's go!</p>
              </div>

              <!-- account social -->
              <div class="account__social">
                <a href="#" class="account__social-btn"><span><img src="assets/images/others/google.svg"
                      alt="google icon"></span>
                  Continue with google
                </a>
              </div>

              <!-- account divider -->
              <div class="account__divider account__divider--style1">
                <span>or</span>
              </div>

              <!-- account form -->
                <div class="container">

                    <h2 style="text-align: center;">Login Here</h2>

                 <form action="login_process.php" method="POST" style="display: flex; flex-direction: column;">
                   <input type="number" id="mob_number" name="mob_number" style="padding: 10px; margin-bottom: 16px; border: 1px solid #ccc; border-radius: 4px;" placeholder="Enter your Mobile Number" required>
                   <input type="password" id="password" name="password" style="padding: 10px; margin-bottom: 16px; border: 1px solid #ccc; border-radius: 4px;" placeholder="Enter your Password" required>   
                   <button type="submit" name="submit" style="padding: 12px; background-color: #4CAF50; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 16px;">Login</button>
                </form>
             </div>
                
              <div class="account__switch">
                <p>Don't have an account? <a href="register.php">Register</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="account__shape">
      <span class="account__shape-item account__shape-item--1"><img src="assets/images/contact/4.png"
          alt="shape-icon"></span>
    </div>
  </section>
  <!-- ===============>> account end here <<================= -->





  <!-- ===============>> footer start here <<================= -->
        <?php 
           include("php_include/footer.php");
        ?>
  <!-- ===============>> footer end here <<================= -->




  <!-- vendor plugins -->

  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/all.min.js"></script>
  <script src="assets/js/swiper-bundle.min.js"></script>
  <script src="assets/js/aos.js"></script>
  <script src="assets/js/fslightbox.js"></script>
  <script src="assets/js/purecounter_vanilla.js"></script>



  <script src="assets/js/custom.js"></script>


</body>


</html>