<?php
    session_start();
    include('php_include/check_login.php');
    include("php_include/connect.php");
    $userid = $_SESSION['userid'];
    if(isset($_POST['submit'])){
        $nominal_name=mysqli_real_escape_string($con,$_POST['name']);
        $nominal_age=mysqli_real_escape_string($con,$_POST['age']);
        $nominal_dob=mysqli_real_escape_string($con,$_POST['dob']);
        $nominal_gender=mysqli_real_escape_string($con,$_POST['gender']);
        $relationship=mysqli_real_escape_string($con,$_POST['relationship']);
        $trn_password=mysqli_real_escape_string($con,$_POST['trn_password']);

            $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid' AND `trn_password` = '$trn_password'");
            if(mysqli_num_rows($query_password_check)==1){

               $query=mysqli_query($con,"UPDATE `user` SET `nominal_name`='$nominal_name',`nominal_age`='$nominal_age',`nominal_dob`='$nominal_dob',`nominal_gender`='$nominal_gender',`relationship`='$relationship' WHERE `userid` = '$userid'");
                                            
               if($query){
                         echo "<script>alert('Nominal Details updated');window.location.assign('index.php');</script>";
                    }else{
                         echo "<script>alert('Nominal Details failed');window.location.assign('edit_nominal.php');</script>";
                    }
            }else{
                    echo "<script>alert('TRN Password Entered is wrong!');window.location.assign('edit_nominal.php');</script>";
            }
    }else{
        
    }
    
?>