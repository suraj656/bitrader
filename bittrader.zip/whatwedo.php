<!DOCTYPE html>
<html lang="en" data-bs-theme="light">


<head>
   <?php 
           include("php_include/head.php");
    ?>
</head>

<body>

  <!-- ===============>> Preloader start here <<================= -->
  <div class="preloader">
    <img src="assets/images/logo/preloader.png" alt="preloader icon">
  </div>
  <!-- ===============>> Preloader end here <<================= -->



  <!-- ===============>> light&dark switch start here <<================= -->
  <div class="lightdark-switch">
    <span class="switch-btn" id="btnSwitch"><img src="assets/images/icon/moon.svg" alt="light-dark-switchbtn"
        class="swtich-icon"></span>
  </div>
  <!-- ===============>> light&dark switch start here <<================= -->





  <!-- ===============>> Header section start here <<================= -->
        <?php 
           include("php_include/header.php");
        ?>
  <!-- ===============>> Header section end here <<================= -->


  <!-- ================> Page header start here <================== -->
  <section class="page-header bg--cover" style="background-image:url(assets/images/header/1.png)">
    <div class="container">
      <div class="page-header__content" data-aos="fade-right" data-aos-duration="1000">
        <h2>What We Do</h2>
        <nav style="--bs-breadcrumb-divider: '/';" aria-label="breadcrumb">
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item "><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">What We Do</li>
          </ol>
        </nav>
      </div>
      <div class="page-header__shape">
        <span class="page-header__shape-item page-header__shape-item--1"><img src="assets/images/header/2.png"
            alt="shape-icon"></span>
      </div>
    </div>
  </section>
  <!-- ================> Page header end here <================== -->


   <!-- ===============>> Service section start here <<================= -->
  <section class="service padding-top padding-bottom">
    <div class="section-header section-header--max50">
      <h2 class="mb-10 mt-minus-5"><span>services </span>We offer</h2>
      <p>We offer the best services around - from installations to repairs, maintenance, and more!</p>
    </div>
    <div class="container">
      <div class="service__wrapper">
        <div class="row g-4 align-items-center">
          <div class="col-sm-6 col-md-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="800">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/1.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                  <h5 > <a class="stretched-link" href="#">Strategy Consulting</a> </h5>
                  <p class="mb-0">A social assistant that's flexible can accommodate your schedule and needs, making
                    life easier.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1000">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/2.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                  <h5 > <a class="stretched-link" href="#"> Financial Advisory</a> </h5>
                  <p class="mb-0">Modules transform smart trading by automating processes and improving decision-making.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1200">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/3.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                  <h5 > <a class="stretched-link" href="#">Management</a> </h5>
                  <p class="mb-0">There, it's me, your friendly neighborhood reporter's news analyst processes and
                    improving</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="800">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/4.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                  <h5 > <a class="stretched-link" href="#">Supply Optimization </a>
                  </h5>
                  <p class="mb-0">Hey, have you checked out that new cryptocurrency platform? It's pretty cool and easy
                    to use!</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1000">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/5.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                  <h5 > <a class="stretched-link" href="#">HR consulting</a> </h5>
                  <p class="mb-0">Hey guys, just a quick update on exchange orders. There have been some changes
                    currency!</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1200">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/6.png" alt="service-icon">
                </div>
                <div class="service__item-content">
                  <h5 > <a class="stretched-link" href="#">Marketing consulting</a>
                  </h5>
                  <p class="mb-0">Hey! Just wanted to let you know that the price notification module processes is now
                    live!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> Service section start here <<================= -->


  <!-- ===============>> Team section start here <<================= -->
  <section class="team padding-top padding-bottom bg-color">
    <div class="section-header section-header--max50">
      <h2 class="mb-10 mt-minus-5">Meet our <span>advisers</span></h2>
      <p>Hey everyone, meet our amazing advisers! They're here to help and guide us through anything.</p>
    </div>
    <div class="container">
      <div class="team__wrapper">
        <div class="row g-4 align-items-center">
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="800">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/1.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Dianne Russell</a> </h6>
                      <p class="mb-0">Trade Captain</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="900">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/2.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Theresa Webb</a> </h6>
                      <p class="mb-0">Strategic Advisor</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="1000">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/3.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Courtney Henry</a> </h6>
                      <p class="mb-0">Management Consultant</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="1100">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/4.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Albert Flores</a> </h6>
                      <p class="mb-0">Development Specialist</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="800">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/5.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Darrell Steward</a> </h6>
                      <p class="mb-0">Growth Strategist</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="900">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/6.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Wade Warren</a> </h6>
                      <p class="mb-0">Trade Consultant</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="1000">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/7.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Cody Fisher</a> </h6>
                      <p class="mb-0">HR Consultant</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="team__item team__item--shape" data-aos="fade-up" data-aos-duration="1100">
              <div class="team__item-inner team__item-inner--shape">
                <div class="team__item-thumb team__item-thumb--style1">
                  <img src="assets/images/team/8.png" alt="Team Image" class="dark">
                </div>
                <div class="team__item-content team__item-content--style1">
                  <div class="team__item-author team__item-author--style1">
                    <div class="team__item-authorinfo">
                      <h6 class="mb-1"><a href="#" class="stretched-link">Bessie Cooper</a> </h6>
                      <p class="mb-0">Financial Advisor</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="text-center">
            <a href="#" class="trk-btn trk-btn--border trk-btn--primary mt-25">View more </a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> Team section start here <<================= -->



  <!-- ===============>> Testimonial section start here <<================= -->
  <section class="testimonial padding-top padding-bottom-style2 bg-color">
    <div class="container">
      <div class="section-header d-md-flex align-items-center justify-content-between">
        <div class="section-header__content">
          <h2 class="mb-10">connect with <span>our Clients </span></h2>
          <p class="mb-0">We love connecting with our clients to hear about their experiences and how we can improve.
          </p>
        </div>
        <div class="section-header__action">
          <div class="swiper-nav">
            <button class="swiper-nav__btn testimonial__slider-prev"><i class="fa-solid fa-angle-left"></i></button>
            <button class="swiper-nav__btn testimonial__slider-next active"><i
                class="fa-solid fa-angle-right"></i></button>
          </div>
        </div>
      </div>
      <div class="testimonial__wrapper" data-aos="fade-up" data-aos-duration="1000">
        <div class="testimonial__slider swiper">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="testimonial__item testimonial__item--style1">
                <div class="testimonial__item-inner">
                  <div class="testimonial__item-content">
                    <p class="mb-0">
                      The above testimonial is about Martha Chumo, who taught herself to code in one summer. This
                      testimonial example works because it allows prospective customers to see themselves in
                      Codeacademy’s current customer base.
                    </p>
                    <div class="testimonial__footer">
                      <div class="testimonial__author">
                        <div class="testimonial__author-thumb">
                          <img src="assets/images/testimonial/1.png" alt="author">
                        </div>
                        <div class="testimonial__author-designation">
                          <h6>Mobarok Hossain</h6>
                          <span>Trade Master</span>
                        </div>
                      </div>
                      <div class="testimonial__quote">
                        <span><i class="fa-solid fa-quote-right"></i></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="testimonial__item testimonial__item--style1">
                <div class="testimonial__item-inner">
                  <div class="testimonial__item-content">
                    <p class="mb-0">
                      In the above testimonial, a customer named Jeanine shares her experience with Briogeo’s products.
                      While the post is scattered with too many product mentions, it takes full advantage of its real
                      estate by allowing the writer to tell
                    </p>
                    <div class="testimonial__footer">
                      <div class="testimonial__author">
                        <div class="testimonial__author-thumb">
                          <img src="assets/images/testimonial/2.png" alt="author">
                        </div>
                        <div class="testimonial__author-designation">
                          <h6>Guy Hawkins</h6>
                          <span>Trade Boss</span>
                        </div>
                      </div>
                      <div class="testimonial__quote">
                        <span><i class="fa-solid fa-quote-right"></i></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="testimonial__item testimonial__item--style1">
                <div class="testimonial__item-inner">
                  <div class="testimonial__item-content">
                    <p class="mb-0">
                      The above testimonial is about Martha Chumo, who taught herself to code in one summer. This
                      testimonial example works because it allows prospective customers to see themselves in
                      Codeacademy’s current customer base.
                    </p>
                    <div class="testimonial__footer">
                      <div class="testimonial__author">
                        <div class="testimonial__author-thumb">
                          <img src="assets/images/testimonial/6.png" alt="author">
                        </div>
                        <div class="testimonial__author-designation">
                          <h6>Belal Hossain</h6>
                          <span>Trade Genius</span>
                        </div>
                      </div>
                      <div class="testimonial__quote">
                        <span><i class="fa-solid fa-quote-right"></i></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> Testimonial section start here <<================= -->




  <!-- ===============>> footer start here <<================= -->
    <?php 
           include("php_include/footer.php");
    ?>
  <!-- ===============>> footer end here <<================= -->

  <!-- vendor plugins -->

  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/all.min.js"></script>
  <script src="assets/js/swiper-bundle.min.js"></script>
  <script src="assets/js/aos.js"></script>
  <script src="assets/js/fslightbox.js"></script>
  <script src="assets/js/purecounter_vanilla.js"></script>



  <script src="assets/js/custom.js"></script>


</body>

</html>