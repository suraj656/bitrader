<?php
   include("php_include/connect.php");
   if(isset($_POST['submit'])){
       $userid='DR'.rand('8888888','9999999').'S';;
       $name = mysqli_real_escape_string($con, $_POST["name"]);
       $email=mysqli_real_escape_string($con, $_POST["email"]);
       $mob_num =mysqli_real_escape_string($con, $_POST["mob_number"]);
       $password=mysqli_real_escape_string($con, $_POST["password"]);
       $refid=mysqli_real_escape_string($con, $_POST["ref_id"]);
       
           $query=mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid'");
           if(mysqli_num_rows($query)==0){
               
               $query=mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$refid'");
           if(mysqli_num_rows($query)!=0){  

             
              $query=mysqli_query($con,"SELECT * FROM `user` WHERE `mob_num`='$mob_num'");
              if(mysqli_num_rows($query)==0){
              
             $query2=mysqli_query($con,"INSERT INTO `user`( `userid`, `name`, `email`, `mob_num`, `password`, `trn_password`, `refid`) VALUES ('$userid','$name','$email','$mob_num','$password','$password', '$refid')");
             $query3=mysqli_query($con,"INSERT INTO `kyc`(`userid`, `password`, `trn_password`) VALUES ('$userid','$password','$password')");
             $query4=mysqli_query($con,"INSERT INTO `bank_details`( `userid`, `password`, `trn_password`) VALUES ('$userid','$password','$password')");
             if($query2 and $query3 and $query4){
                echo"<script>alert('Registeration Successful');window.location.assign('login.php');</script>";
            }else{
                 echo"<script>alert('Registeration UnSuccessful');window.location.assign('register.php');</script>";
            }
            
              }else{
                  echo"<script>alert('This Mobile Already Register');window.location.assign('register.php');</script>";
              }
           }else{
                echo"<script>alert('Referal ID Does not Exist');window.location.assign('register.php');</script>";
           }
           }else{
            echo"<script>alert('This Userid Already Register');window.location.assign('register.php');</script>";   
           }
       
   }else{
       
   }
    ?>