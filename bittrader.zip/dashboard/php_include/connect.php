<?php
	$db_host = "localhost";
	$db_user = "suraj_project_user";
	$db_pass = "J7QGcFZLviw";
	$db_name = "suraj_project";
	//data connect process
	$con =  mysqli_connect($db_host,$db_user,$db_pass,$db_name);
	if(mysqli_connect_error()){
		echo 'connect to database failed';
	}
?>
