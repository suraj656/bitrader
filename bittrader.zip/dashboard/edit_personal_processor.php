<?php
    session_start();
    include('php_include/check_login.php');
    include("php_include/connect.php");
    $userid = $_SESSION['userid'];
    if(isset($_POST['submit'])){
        $mob_num=mysqli_real_escape_string($con,$_POST['mobileNumber']);
        $email=mysqli_real_escape_string($con,$_POST['email']);
        $dob=mysqli_real_escape_string($con,$_POST['dob']);
        $gender=mysqli_real_escape_string($con,$_POST['gender']);
        $age=mysqli_real_escape_string($con,$_POST['age']);
        $area=mysqli_real_escape_string($con,$_POST['area']);
        $street=mysqli_real_escape_string($con,$_POST['street']);
        $address=mysqli_real_escape_string($con,$_POST['address']);
        $country=mysqli_real_escape_string($con,$_POST['country']);
        $state=mysqli_real_escape_string($con,$_POST['state']);
        $district=mysqli_real_escape_string($con,$_POST['district']);
        $taluk=mysqli_real_escape_string($con,$_POST['taluk']);
        $city=mysqli_real_escape_string($con,$_POST['city']);
        $pincode=mysqli_real_escape_string($con,$_POST['pincode']);
        $trn_password=mysqli_real_escape_string($con,$_POST['trn_password']);
        
        
            $query_password_check= mysqli_query($con,"SELECT * FROM `user` WHERE `userid`='$userid' AND `trn_password` = '$trn_password'");
            if(mysqli_num_rows($query_password_check)==1){

               $query=mysqli_query($con,"UPDATE `user` SET `email`='$email',`mob_num`='$mob_num',`gender`='$gender',`dob`='$dob',`age`='$age',`area`='$area',`street`='$street',`address`='$address',`country`='$country',`state`='$state',`district`='$district',`taluk`='$taluk',`city`='$city',`pincode`='$pincode' WHERE `userid` = '$userid'");
                                            
               if($query){
                         echo "<script>alert('Profile updated');window.location.assign('index.php');</script>";
                    }else{
                         echo "<script>alert('Profile update failed');window.location.assign('edit_personal.php');</script>";
                    }
            }else{
                    echo "<script>alert('TRN Password Entered is wrong!');window.location.assign('edit_personal.php');</script>";
            }
    }else{
        
    }
    
?>